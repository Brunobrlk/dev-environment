#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end
#set( $MODEL_NAME = $FILE_NAME.replace("sAdapter", "") )
#set( $VH_NAME = $MODEL_NAME + "ViewHolder" )
#set( $DF_CALLBACK_NAME = $MODEL_NAME + "sDiffCallback" )
#set( $ITEM_LAYOUT = "R.layout.item_" + $MODEL_NAME.toLowerCase() )

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import #parse("CustomPackage.kt").R
import #parse("CustomPackage.kt").domain.$MODEL_NAME

class $FILE_NAME() : ListAdapter<$MODEL_NAME, RecyclerView.ViewHolder>($DF_CALLBACK_NAME) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ${VH_NAME}.from(parent)

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is $VH_NAME -> {
                val item = getItem(position)
                holder.bind(item)
            }
        }
    }
    
    class $VH_NAME(itemView: View) : RecyclerView.ViewHolder(itemView){
        fun bind(item: $MODEL_NAME){
            
        }
        
        companion object {
            fun from(parent: ViewGroup): $VH_NAME {
                val view = LayoutInflater.from(parent.context).inflate($ITEM_LAYOUT, parent, false)
                return $VH_NAME(view)
            }
        }
    }
}

object $DF_CALLBACK_NAME: DiffUtil.ItemCallback<$MODEL_NAME>(){
    override fun areItemsTheSame(oldItem: $MODEL_NAME, newItem: $MODEL_NAME) = oldItem == newItem
    override fun areContentsTheSame(oldItem: $MODEL_NAME, newItem: $MODEL_NAME) = oldItem == newItem
}