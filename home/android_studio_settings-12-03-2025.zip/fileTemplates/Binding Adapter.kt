#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end
#set( $MODEL_NAME = $FILE_NAME.replace("sAdapter", "") )
#set( $VH_NAME = $MODEL_NAME + "ViewHolder" )
#set( $DF_CALLBACK_NAME = $MODEL_NAME + "sDiffCallback" )
#set( $MODEL_NAME_L = $MODEL_NAME.toLowerCase() )
#set( $ITEM_LAYOUT = "R.layout.item_" + $MODEL_NAME_L )
#set( $BINDING = "Item" + $MODEL_NAME + "Binding" )

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import #parse("CustomPackage.kt").domain.$MODEL_NAME
import #parse("CustomPackage.kt").databinding.$BINDING

class $FILE_NAME(#if(${ClickListener_Interface_Name1} != "")private val _$ClickListener_Interface_Name1.substring(0,1).toLowerCase()$ClickListener_Interface_Name1.substring(1): ${ClickListener_Interface_Name1}#end#if(${ClickListener_Interface_Name2} != ""), private val _$ClickListener_Interface_Name2.substring(0,1).toLowerCase()$ClickListener_Interface_Name2.substring(1): ${ClickListener_Interface_Name2}#end#if(${ClickListener_Interface_Name3} != ""), private val _$ClickListener_Interface_Name3.substring(0,1).toLowerCase()$ClickListener_Interface_Name3.substring(1): ${ClickListener_Interface_Name3}#end): ListAdapter<$MODEL_NAME, RecyclerView.ViewHolder>($DF_CALLBACK_NAME) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ${VH_NAME}.from(parent)

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is $VH_NAME -> {
                holder.bind(getItem(position))
            }
        }
    }
    
    class $VH_NAME(private val _binding: $BINDING) : RecyclerView.ViewHolder(_binding.root){
        fun bind($MODEL_NAME_L: $MODEL_NAME){
            
        }
        
        companion object {
            fun from(parent: ViewGroup): $VH_NAME {
                val inflater = LayoutInflater.from(parent.context)
                val binding = ${BINDING}.inflate(inflater, parent, false)
                return $VH_NAME(binding)
            }
        }
    }
}

object $DF_CALLBACK_NAME: DiffUtil.ItemCallback<$MODEL_NAME>(){
    override fun areItemsTheSame(oldItem: $MODEL_NAME, newItem: $MODEL_NAME) = oldItem == newItem
    override fun areContentsTheSame(oldItem: $MODEL_NAME, newItem: $MODEL_NAME) = oldItem == newItem
}

#if(${ClickListener_Interface_Name1} != "")
interface $ClickListener_Interface_Name1 {
    fun on$ClickListener_Interface_Name1.replace("Listener", "")()
}
#end

#if(${ClickListener_Interface_Name2} != "")
interface $ClickListener_Interface_Name2 {
    fun on$ClickListener_Interface_Name2.replace("Listener", "")()
}
#end

#if(${ClickListener_Interface_Name3} != "")
interface $ClickListener_Interface_Name3 {
    fun on$ClickListener_Interface_Name3.replace("Listener", "")()
}
#end