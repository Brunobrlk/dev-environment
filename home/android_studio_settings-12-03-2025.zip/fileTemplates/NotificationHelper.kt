#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import #parse("CustomPackage.kt").R

class NotificationHelper private constructor(private val context: Context) {
    private var notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private var channelId = "default_channel_id"
    private var channelName = "Default Channel"
    private var channelImportance = NotificationManager.IMPORTANCE_DEFAULT
    private var channelDescription = "Default Description"
    private var channelHelper: NotificationChannelHelper? = null

    private var id: Int = NOT_SPECIFIED_ID
    private var title: String? = null
    private var content: String? = null
    private var icon: Int = R.drawable.ic_launcher_background
    private var actions: List<NotificationCompat.Action>? = null
    private var notification: Notification? = null

    fun setId(id: Int) = apply { this.id = id }
    fun setTitle(title: String) = apply { this.title = title }
    fun setContent(content: String) = apply { this.content = content }
    fun setIcon(icon: Int) = apply { this.icon = icon }
    fun setActions(actions: List<NotificationCompat.Action>) = apply { this.actions = actions }
    fun setChannel(channelHelper: NotificationChannelHelper) = apply { this.channelHelper = channelHelper }

    fun build() = apply {
        createNotificationChannel()
        createNotificationUI()
    }

    fun showNotification(){
        notification?.let {
            notificationManager.notify(id, notification)
        } ?: Log.d("NotificationHelper","Can't show notification. E: notification is null")
    }

    private fun createNotificationUI() {
        val notificationBuilder = NotificationCompat.Builder(context, channelId)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(icon)

        actions?.let { actions ->
            for (action in actions) notificationBuilder.addAction(action)
        }

        notification = notificationBuilder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            channelHelper?.let {
                channelId = it.channelId
                channelName = it.channelName
                channelImportance = it.channelImportance
                channelDescription = it.channelDescription
            }

            val channel = NotificationChannel(channelId, channelName, channelImportance).apply { description = channelDescription }

            notificationManager.createNotificationChannel(channel)
        }
    }

    fun deleteAllNotificationChannels(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            for(channel in notificationManager.notificationChannels) notificationManager.deleteNotificationChannel(channel.id)
        }
    }

    fun deleteNotificationChannel(channelId: String){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            notificationManager.deleteNotificationChannel(channelId)
        }
    }

    companion object {
        const val NOT_SPECIFIED_ID = 1000
        const val ONE_TIME_ID = 1001

        fun createNotification(context: Context): NotificationHelper {
            return NotificationHelper(context)
        }
    }

    data class NotificationChannelHelper(val channelId: String, val channelName: String, val channelImportance: Int, val channelDescription: String)
}